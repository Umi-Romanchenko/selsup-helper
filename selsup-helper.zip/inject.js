(function () {
  if (window.__SBH_INJECTED__) return;
  window.__SBH_INJECTED__ = true;
  const log = (...a) => console.log('[SBH]', ...a);

  const DEFAULT = { action: 'disable',
                    targets: { first: false, second: true },
                    mps: { wb: true, ozon: true, ym: false } };
  let state = JSON.parse(JSON.stringify(DEFAULT));
  let applying = false;
  let lastFind = null, lastRawFind = null, lastFindUrl = null, putCount = 0;
  let saveRunning = false;

  try {
    const raw = sessionStorage.getItem('sbh-cfg');
    if (raw) {
      const cfg = JSON.parse(raw);
      if (cfg && cfg.enabled) { state = { ...DEFAULT, ...(cfg.state || {}) }; applying = true; }
    }
  } catch {}

  function persistCfg() {
    try {
      if (applying) sessionStorage.setItem('sbh-cfg', JSON.stringify({ enabled: true, state }));
      else sessionStorage.removeItem('sbh-cfg');
    } catch {}
  }

  // ---------- кэш критичных заголовков ----------
  const criticalHeaders = {};
  const HC_RE = /^X-(XSRF|Demo|Requested)/i;

  const origXhrSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (HC_RE.test(k)) {
      if (criticalHeaders[k] !== v) log('hdr req:', k, '=', String(v).slice(0, 20));
      criticalHeaders[k] = v;
    }
    return origXhrSetHeader.call(this, k, v);
  };

  const origFetch = window.fetch.bind(window);
  window.fetch = async function (...args) {
    try {
      const req = args[0]; const opts = args[1] || {};
      const headers = opts.headers || (req instanceof Request ? req.headers : null);
      if (headers instanceof Headers) {
        headers.forEach((v, k) => { if (HC_RE.test(k)) criticalHeaders[k] = v; });
      } else if (Array.isArray(headers)) {
        for (const [k, v] of headers) if (HC_RE.test(k)) criticalHeaders[k] = v;
      } else if (headers && typeof headers === 'object') {
        for (const k of Object.keys(headers)) if (HC_RE.test(k)) criticalHeaders[k] = headers[k];
      }
    } catch {}
    return origFetch(...args);
  };

  function csrfFromCookie() {
    const m = document.cookie.match(/(?:^|; )XSRF-TOKEN=([^;]*)/);
    return m ? decodeURIComponent(m[1]) : null;
  }

  // ---------- patch / stats ----------
  function buildPatch(data) {
    const patch = {};
    for (const m of data.rows || []) for (const v of m.views || []) for (const s of v.sizes || []) {
      const bcs = s.barcodes || []; if (!bcs.length) continue;
      const pIdx = bcs.findIndex(b => b.primaryBarcode === true);
      const firstIdx = pIdx >= 0 ? pIdx : 0;
      const list = [];
      if (state.targets.first) list.push(bcs[firstIdx]);
      if (state.targets.second) bcs.forEach((b, i) => { if (i !== firstIdx) list.push(b); });
      const perBc = {};
      for (const bc of list) {
        const p = {};
        if (state.mps.wb)   p.useInWildberries  = state.action === 'enable';
        if (state.mps.ozon) p.useInOzon         = state.action === 'enable';
        if (state.mps.ym)   p.useInYandexMarket = state.action === 'enable';
        if (Object.keys(p).length) perBc[bc.id] = p;
      }
      if (Object.keys(perBc).length) patch[s.id] = perBc;
    }
    return patch;
  }
  function applyPatch(data, patch) {
    for (const m of data.rows || []) for (const v of m.views || []) for (const s of v.sizes || []) {
      const sp = patch[s.id]; if (!sp) continue;
      for (const bc of s.barcodes || []) if (sp[bc.id]) Object.assign(bc, sp[bc.id]);
    }
    return data;
  }
  function computeStats(data) {
    let sizes = 0, barcodes = 0;
    for (const m of data.rows || []) for (const v of m.views || []) for (const s of v.sizes || []) {
      sizes++; barcodes += (s.barcodes || []).length;
    }
    return { sizes, barcodes };
  }
  function pushStats(patched) {
    const base = lastFind ? computeStats(lastFind) : { sizes: 0, barcodes: 0 };
    const modelsTotal = lastRawFind ? (lastRawFind.rows || []).length : 0;
    window.postMessage({ __sbh: 'stats', stats: {
      ...base, models: modelsTotal,
      applying, query: lastFindUrl ? (() => { try { return (new URL(lastFindUrl).searchParams.get('query') || '').trim(); } catch { return ''; } })() : null,
      putCount, patched: !!patched,
      action: state.action, targets: state.targets, mps: state.mps,
      saveRunning,
      csrf: !!criticalHeaders['X-XSRF-TOKEN'],
      demoCtx: criticalHeaders['X-Demo-Context-User-Id'] || null,
    } }, '*');
  }
  function maybePatch(data, url) {
    lastRawFind = JSON.parse(JSON.stringify(data));
    lastFind = data; lastFindUrl = url;
    if (!applying) { pushStats(false); return data; }
    const patch = buildPatch(data);
    if (!Object.keys(patch).length) { pushStats(false); return data; }
    pushStats(true);
    return applyPatch(JSON.parse(JSON.stringify(data)), patch);
  }

  // ---------- XHR intercept find ----------
  const IS_FIND = u => typeof u === 'string' && /\/api\/model\/find(\?|$)/.test(u);
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url, ...r) {
    this.__sbh_url = url; this.__sbh_method = (method || 'GET').toUpperCase();
    return origOpen.call(this, method, url, ...r);
  };
  const origTextGet = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'responseText').get;
  const origRespGet = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response').get;
  Object.defineProperty(XMLHttpRequest.prototype, 'responseText', {
    configurable: true,
    get() {
      let t; try { t = origTextGet.call(this); } catch { return origTextGet.call(this); }
      if (!IS_FIND(this.__sbh_url) || this.readyState !== 4) return t;
      try {
        const d = JSON.parse(t); const p = maybePatch(d, this.__sbh_url);
        return p === d ? t : JSON.stringify(p);
      } catch { return t; }
    }
  });
  Object.defineProperty(XMLHttpRequest.prototype, 'response', {
    configurable: true,
    get() {
      const r = origRespGet.call(this);
      if (!IS_FIND(this.__sbh_url) || this.readyState !== 4) return r;
      try {
        if (typeof r === 'string') {
          const d = JSON.parse(r); const p = maybePatch(d, this.__sbh_url);
          return p === d ? r : JSON.stringify(p);
        }
        if (r && typeof r === 'object' && r.rows) return maybePatch(JSON.parse(JSON.stringify(r)), this.__sbh_url);
      } catch {}
      return r;
    }
  });

  // ---------- хиджек Save ----------
  const SAVE_BTN_SELECTOR = '.fixedButtonPanel button.MuiButton-containedPrimary';
  let saveBtnObserver = null;

  function hijackSaveButton() {
    const btn = document.querySelector(SAVE_BTN_SELECTOR);
    if (!btn || btn.__sbh_hijacked) return;
    btn.__sbh_hijacked = true;
    btn.__sbh_origBg = btn.style.background;
    btn.__sbh_origColor = btn.style.color;
    btn.__sbh_origText = btn.textContent;
    btn.style.background = '#fb8c00';
    btn.style.color = '#fff';
    btn.textContent = '💾 Сохранить (наш)';
    btn.__sbh_handler = (e) => {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      if (saveRunning) return;
      if (confirm('Сохранить на сервер только ШК по нашим правилам?\n\nДругие изменения в других столбцах НЕ будут отправлены — их сохраняй обычной кнопкой SelSup.')) {
        applyAndSave();
      }
    };
    btn.addEventListener('click', btn.__sbh_handler, true);
    log('save button hijacked');
  }
  function releaseSaveButton() {
    const btn = document.querySelector(SAVE_BTN_SELECTOR);
    if (!btn || !btn.__sbh_hijacked) return;
    btn.style.background = btn.__sbh_origBg || '';
    btn.style.color = btn.__sbh_origColor || '';
    if (btn.__sbh_origText != null) btn.textContent = btn.__sbh_origText;
    if (btn.__sbh_handler) btn.removeEventListener('click', btn.__sbh_handler, true);
    btn.__sbh_hijacked = false; btn.__sbh_handler = null;
    log('save button released');
  }
  function attachSaveObserver() {
    if (saveBtnObserver) return;
    if (!document.body) { setTimeout(attachSaveObserver, 100); return; }
    try {
      saveBtnObserver = new MutationObserver(() => { if (applying) hijackSaveButton(); });
      saveBtnObserver.observe(document.body, { childList: true, subtree: true });
      hijackSaveButton();
    } catch (e) { log('observer error:', e); }
  }
  function startSaveButtonWatch() { attachSaveObserver(); }
  function stopSaveButtonWatch() {
    if (saveBtnObserver) { saveBtnObserver.disconnect(); saveBtnObserver = null; }
    releaseSaveButton();
  }

  // ---------- сохранение ----------
  function buildSaveBody(model, patch) {
    const m = JSON.parse(JSON.stringify(model));
    for (const v of m.views || []) for (const s of v.sizes || []) {
      const sp = patch[s.id]; if (!sp) continue;
      for (const bc of s.barcodes || []) if (sp[bc.id]) Object.assign(bc, sp[bc.id]);
    }
    m.hasChanges = true;
    return m;
  }
  function needsSave(model, patch) {
    for (const v of model.views || []) for (const s of v.sizes || []) {
      const sp = patch[s.id]; if (!sp) continue;
      for (const bc of s.barcodes || []) {
        const bp = sp[bc.id]; if (!bp) continue;
        for (const k of Object.keys(bp)) if (bc[k] !== bp[k]) return true;
      }
    }
    return false;
  }

  function makeHeaders(csrfToken) {
    const h = { 'Content-Type': 'application/json', 'Accept': 'application/json, text/plain, */*' };
    if (criticalHeaders['X-Demo-Context-User-Id']) h['X-Demo-Context-User-Id'] = criticalHeaders['X-Demo-Context-User-Id'];
    if (csrfToken) h['X-XSRF-TOKEN'] = csrfToken;
    return h;
  }

  function postUpdateModel(body, csrfToken) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/sb19/api/product/updateModel', true);
      xhr.withCredentials = true;
      const h = makeHeaders(csrfToken);
      for (const k of Object.keys(h)) xhr.setRequestHeader(k, h[k]);
      xhr.addEventListener('loadend', () => resolve({ status: xhr.status, body: xhr.responseText }));
      xhr.addEventListener('error', () => resolve({ status: 0, body: 'network error' }));
      xhr.send(JSON.stringify(body));
    });
  }

  async function trySaveWithCsrf(buildBody, tokens) {
    let lastErr = null;
    for (const tk of tokens) {
      if (!tk) continue;
      const res = await postUpdateModel(buildBody, tk);
      putCount++; pushStats();
      if (res.status >= 200 && res.status < 300) return { ok: true, status: res.status, body: res.body, token: tk };
      lastErr = { status: res.status, body: res.body, token: tk };
      if (res.status === 403) continue;
      return { ok: false, ...lastErr };
    }
    return { ok: false, ...(lastErr || { status: 0, body: 'no tokens' }) };
  }

  function findOverrides(sentModel, respObj) {
    let count = 0;
    for (let i = 0; i < (sentModel.views || []).length; i++) {
      const sv = sentModel.views[i]; const rv = respObj.views?.[i]; if (!rv) continue;
      for (let j = 0; j < (sv.sizes || []).length; j++) {
        const ss = sv.sizes[j]; const rs = rv.sizes?.[j]; if (!rs) continue;
        for (let k = 0; k < (ss.barcodes || []).length; k++) {
          const sb = ss.barcodes[k]; const rb = rs.barcodes?.[k]; if (!rb || sb.id !== rb.id) continue;
          if (sb.useInWildberries !== rb.useInWildberries ||
              sb.useInOzon !== rb.useInOzon ||
              sb.useInYandexMarket !== rb.useInYandexMarket) count++;
        }
      }
    }
    return count;
  }

  async function applyAndSave() {
    if (saveRunning) return;
    if (!lastRawFind) {
      window.postMessage({ __sbh: 'saveResult', result: { error: 'Нет данных find — примени фильтр' } }, '*');
      return;
    }
    const modelsAll = lastRawFind.rows || [];
    const totalLimit = modelsAll.length;
    const patch = buildPatch(lastRawFind);
    if (!Object.keys(patch).length) {
      window.postMessage({ __sbh: 'saveResult', result: { error: 'Нечего сохранять (пустой патч)' } }, '*');
      return;
    }
    const models = []; let skipped = 0;
    for (const m of modelsAll) {
      let any = false;
      for (const v of m.views || []) for (const s of v.sizes || []) if (patch[s.id]) { any = true; break; }
      if (!any) continue;
      if (!needsSave(m, patch)) { skipped++; continue; }
      models.push(m);
    }
    if (!models.length) {
      applying = false; persistCfg(); stopSaveButtonWatch(); pushStats();
      window.postMessage({ __sbh: 'saveResult', result: { saved: 0, skipped, total: totalLimit, message: 'Всё уже соответствует' } }, '*');
      return;
    }
    saveRunning = true; pushStats();
    let ok = 0, fail = 0, overrides = 0;
    const errors = [];
    const total = Math.min(models.length, totalLimit);

    for (let i = 0; i < total; i++) {
      const m = models[i];
      window.postMessage({ __sbh: 'saveProgress', progress: {
        current: i + 1, total, modelId: m.id, saved: ok, failed: fail,
      } }, '*');
      try {
        const body = buildSaveBody(m, patch);
        const tokenQueue = [];
        if (criticalHeaders['X-XSRF-TOKEN']) tokenQueue.push(criticalHeaders['X-XSRF-TOKEN']);
        const fromCookie = csrfFromCookie();
        if (fromCookie && !tokenQueue.includes(fromCookie)) tokenQueue.push(fromCookie);

        const r = await trySaveWithCsrf(body, tokenQueue);
        if (r.ok) {
          ok++;
          try { const respObj = JSON.parse(r.body); overrides += findOverrides(body, respObj); } catch {}
        } else {
          fail++;
          errors.push(`model ${m.id}: HTTP ${r.status} ${String(r.body).slice(0, 200)}`);
        }
      } catch (e) {
        fail++;
        errors.push(`model ${m.id}: ${e.message}`);
      }
      pushStats();
    }

    saveRunning = false;
    window.postMessage({ __sbh: 'saveResult', result: {
      saved: ok, failed: fail, skipped, total: totalLimit, overrides, errors: errors.slice(0, 5),
    } }, '*');
    applying = false; persistCfg(); stopSaveButtonWatch(); pushStats();
  }

  // ---------- СНАЧАЛА подписываемся на сообщения ----------
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__sbh === 'setCfg') {
      const cfg = e.data.cfg || {};
      applying = !!cfg.enabled;
      state = { ...DEFAULT, ...(cfg.state || state) };
      persistCfg();
      try { if (applying) startSaveButtonWatch(); else stopSaveButtonWatch(); } catch (e) { log('watch err', e); }
      pushStats();
    }
    if (e.data.__sbh === 'needStats') pushStats();
    if (e.data.__sbh === 'reload') location.reload();
    if (e.data.__sbh === 'applySave') applyAndSave();
  });

  // сообщаем bridge что мы на месте (даже если что-то ниже упадёт)
  window.postMessage({ __sbh: 'injectReady' }, '*');

  // затем стартовые вызовы
  try { if (applying) startSaveButtonWatch(); } catch (e) { log('init watch err', e); }
  pushStats();
  log('injected v1.2, applying=' + applying);
})();