(function () {
  // иконка — через background service worker, т.к. chrome.action в content script недоступен
  function updateIcon(active) {
    try {
      chrome.runtime.sendMessage({ type: 'sbh-set-icon', active: !!active }).catch(() => {});
    } catch (e) {}
  }

  function readCfg() {
    try { const r = sessionStorage.getItem('sbh-cfg'); return r ? JSON.parse(r) : null; }
    catch { return null; }
  }
  function postCfg(cfg) { window.postMessage({ __sbh: 'setCfg', cfg: cfg || { enabled: false } }, '*'); }

  // СНАЧАЛА регистрируем onMessage — чтобы даже при последующих ошибках попап мог пинговать
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    try {
      if (msg.type === 'sbh-apply') {
        const c = msg.cfg;
        try { if (c && c.enabled) sessionStorage.setItem('sbh-cfg', JSON.stringify(c)); else sessionStorage.removeItem('sbh-cfg'); } catch {}
        postCfg(c);
        updateIcon(c && c.enabled);
        if (msg.reload !== false) setTimeout(() => window.postMessage({ __sbh: 'reload' }, '*'), 50);
        sendResponse({ ok: true }); return;
      }
      if (msg.type === 'sbh-getCfg') { sendResponse({ cfg: readCfg() }); return; }
      if (msg.type === 'sbh-applySave') { window.postMessage({ __sbh: 'applySave' }, '*'); sendResponse({ ok: true }); return; }
      if (msg.type === 'sbh-reload') { window.postMessage({ __sbh: 'reload' }, '*'); sendResponse({ ok: true }); return; }
      if (msg.type === 'sbh-ping') { sendResponse({ ok: true }); return; }
    } catch (e) {
      try { sendResponse({ ok: false, error: String(e) }); } catch {}
    }
  });

  // затем всё остальное
  const cfg = readCfg();
  try { chrome.storage.local.set({ 'sbh-cfg': cfg }); } catch {}
  updateIcon(cfg && cfg.enabled);
  setTimeout(() => postCfg(cfg), 0);

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__sbh === 'stats') {
      try {
        chrome.storage.local.set({ 'sbh-stats': { ...e.data.stats, ts: Date.now() } });
        updateIcon(e.data.stats.applying || e.data.stats.saveRunning);
      } catch {}
    }
    if (e.data.__sbh === 'saveProgress') {
      try { chrome.storage.local.set({ 'sbh-saveProgress': { ...e.data.progress, ts: Date.now() } }); } catch {}
    }
    if (e.data.__sbh === 'saveResult') {
      try {
        chrome.storage.local.set({ 'sbh-saveResult': { ...e.data.result, ts: Date.now() } });
        chrome.storage.local.remove('sbh-saveProgress');
      } catch {}
    }
    if (e.data.__sbh === 'saveStart') {
      try { chrome.storage.local.remove('sbh-saveResult'); } catch {}
    }
  });
})();