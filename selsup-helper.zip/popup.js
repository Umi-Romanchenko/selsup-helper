const $ = s => document.querySelector(s);
const DEFAULT = { action: 'disable',
                  targets: { first: false, second: true },
                  mps: { wb: true, ozon: true, ym: false } };
let state = JSON.parse(JSON.stringify(DEFAULT));
let applying = false;
let tab = null, stats = null, saveResult = null, saveProgress = null;

const showErr = (t) => { const e = $('#err'); e.style.display = 'block'; e.textContent = t; };
const hideErr = () => { $('#err').style.display = 'none'; };

function render() {
  document.querySelectorAll('.seg').forEach(s => {
    const k = s.dataset.key;
    s.querySelectorAll('button').forEach(b => b.classList.toggle('on', state[k] === b.dataset.v));
  });
  document.querySelectorAll('[data-grp]').forEach(g => {
    const grp = g.dataset.grp;
    g.querySelectorAll('input').forEach(i => i.checked = !!state[grp][i.dataset.k]);
  });

  const runBtn = $('#run'), stopBtn = $('#stop'), saveBtn = $('#save');
  const hint = $('#hint'), prog = $('#progress');
  const sr = saveResult || {};

  if (sr.running || stats?.saveRunning) {
    prog.style.display = 'block';
    prog.innerHTML = saveProgress
      ? `<b>Отправляю ${saveProgress.current} из ${saveProgress.total}</b><br>model ${saveProgress.modelId} · сохранено ${saveProgress.saved} · ошибок ${saveProgress.failed}`
      : `<b>Подготовка…</b>`;
  } else if (saveProgress && sr.saved === undefined) {
    prog.style.display = 'block';
    prog.innerHTML = `Обработано ${saveProgress.current} из ${saveProgress.total}`;
  } else {
    prog.style.display = 'none';
  }

  if (applying) {
    runBtn.style.display = 'none';
    stopBtn.style.display = '';
    hint.innerHTML = 'Визуал включён. Кнопка Save в SelSup стала <b style="color:#fb8c00">оранжевой</b> — жми её, чтобы сохранить только ШК.';
    saveBtn.disabled = false;
  } else {
    runBtn.style.display = '';
    stopBtn.style.display = 'none';
    hint.innerHTML = 'Увидишь результат в таблице. Ничего не сохранится без «Применить и сохранить» или оранжевой кнопки в SelSup.';
    saveBtn.disabled = true;
  }
  saveBtn.textContent = '💾 Применить и сохранить';

  const st = $('#st');
  if (sr.saved !== undefined) {
    st.innerHTML =
      `<b style="color:${sr.failed ? '#ef4444' : '#10b981'}">${sr.failed ? 'Ошибка' : 'Готово'}</b><br>` +
      `Сохранено: ${sr.saved} из ${sr.total || '?'}` +
      (sr.failed ? ` · <span class="warn">ошибок: ${sr.failed}</span>` : '') +
      (sr.skipped ? ` · пропущено (уже ок): ${sr.skipped}` : '') +
      (sr.overrides ? `<br><span class="warn">⚠ Сервер скорректировал ${sr.overrides} полей (правило "один ШК")</span>` : '') +
      (sr.errors?.length ? `<br><span class="warn">${sr.errors[0]}</span>` : '') +
      `<br><span style="color:#64748b">Кнопка Save в SelSup снова обычная.</span>`;
    return;
  }
  if (sr.error) { st.innerHTML = `<span class="warn">Ошибка: ${sr.error}</span>`; return; }
  if (!stats) { st.textContent = 'Примени фильтр на странице'; return; }
  st.innerHTML =
    (applying ? `<span class="ok">Визуал активен</span>` : `<span style="color:#64748b">Не активно</span>`) +
    (stats.patched ? ' · <span class="ok">применён</span>' : '') +
    `<br>Моделей: ${stats.models}, строк: ${stats.sizes}, ШК: ${stats.barcodes}` +
    (stats.query ? `<br><span style="color:#64748b">фильтр: "${stats.query}"</span>` : '') +
    (stats.putCount ? ` <span class="warn">⚠ write: ${stats.putCount}</span>` : ' <span class="ok">✓ write: 0</span>') +
    `<br><span style="color:${stats.csrf ? '#10b981' : '#64748b'}">CSRF: ${stats.csrf ? '✓' : '—'}` +
    ` · Demo-ctx: ${stats.demoCtx ? '✓' : '—'}</span>`;
}

async function readStorage() {
  const a = await chrome.storage.local.get(['sbh-cfg', 'sbh-stats', 'sbh-saveResult', 'sbh-saveProgress']);
  const cfg = a['sbh-cfg'];
  if (cfg) { state = { ...DEFAULT, ...(cfg.state || {}) }; applying = !!cfg.enabled; }
  else { state = JSON.parse(JSON.stringify(DEFAULT)); applying = false; }
  stats = a['sbh-stats'] || null;
  saveResult = a['sbh-saveResult'] || null;
  saveProgress = a['sbh-saveProgress'] || null;
}

function buildCfg() { return { enabled: applying, state }; }

async function send(msg) {
  if (!tab || tab.id == null) return null;
  try { return await chrome.tabs.sendMessage(tab.id, msg); } catch { return null; }
}

async function init() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/selsup\.ru/.test(tab.url || '')) {
    showErr('Открой selsup.ru — расширение работает только там.'); render(); return;
  }
  const ping = await send({ type: 'sbh-ping' });
  if (!ping) showErr('Content script не отвечает. F5 в selsup.');
  await readStorage();
  render();

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch['sbh-stats']) { stats = ch['sbh-stats'].newValue; render(); }
    if (ch['sbh-saveResult']) { saveResult = ch['sbh-saveResult'].newValue; render(); }
    if (ch['sbh-saveProgress']) { saveProgress = ch['sbh-saveProgress'].newValue; render(); }
    if (ch['sbh-cfg']) {
      const cfg = ch['sbh-cfg'].newValue;
      if (cfg) { state = { ...DEFAULT, ...(cfg.state || {}) }; applying = !!cfg.enabled; }
      else { state = JSON.parse(JSON.stringify(DEFAULT)); applying = false; }
      render();
    }
  });

  document.querySelectorAll('.seg').forEach(s => {
    const k = s.dataset.key;
    s.querySelectorAll('button').forEach(b => b.onclick = async () => {
      state[k] = b.dataset.v;
      if (applying) { await chrome.storage.local.set({ 'sbh-cfg': buildCfg() }); await send({ type: 'sbh-apply', cfg: buildCfg(), reload: false }); }
      render();
    });
  });
  document.querySelectorAll('[data-grp]').forEach(g => {
    const grp = g.dataset.grp;
    g.querySelectorAll('input').forEach(i => i.onchange = async () => {
      state[grp][i.dataset.k] = i.checked;
      if (applying) { await chrome.storage.local.set({ 'sbh-cfg': buildCfg() }); await send({ type: 'sbh-apply', cfg: buildCfg(), reload: false }); }
      render();
    });
  });

  $('#run').onclick = async () => {
    hideErr(); applying = true;
    const cfg = buildCfg();
    await chrome.storage.local.set({ 'sbh-cfg': cfg });
    await send({ type: 'sbh-apply', cfg, reload: true });
    window.close();
  };
  $('#stop').onclick = async () => {
    hideErr(); applying = false;
    const cfg = buildCfg();
    await chrome.storage.local.set({ 'sbh-cfg': cfg });
    await send({ type: 'sbh-apply', cfg, reload: true });
    window.close();
  };
  $('#save').onclick = async () => {
    if (!applying) return;
    await chrome.storage.local.remove('sbh-saveResult');
    saveResult = { running: true }; render();
    await send({ type: 'sbh-applySave' });
  };
}
init();