console.log('[SBH-bg] loaded v1.4');

const ICON_ON  = 'icons/on.png';
const ICON_OFF = 'icons/off.png';

let lastIcon = null;
let loadedIcons = { on: null, off: null };

// Функция загрузки и конвертации PNG в формат, который Chrome съест на 100%
async function loadImage(path) {
  const url = chrome.runtime.getURL(path);
  const res = await fetch(url);
  if (!res.ok) throw new Error('fetch failed ' + res.status);
  const blob = await res.blob();
  const bitmap = await createImageBitmap(blob);
  
  // Рисуем на прозрачном холсте 128x128 (Chrome сам уменьшит где надо)
  const canvas = new OffscreenCanvas(128, 128);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 128, 128);
  ctx.drawImage(bitmap, 0, 0, 128, 128);
  return ctx.getImageData(0, 0, 128, 128);
}

async function preloadIcons() {
  try {
    loadedIcons.on = await loadImage(ICON_ON);
    loadedIcons.off = await loadImage(ICON_OFF);
    console.log('[SBH-bg] Custom icons loaded successfully');
  } catch (e) {
    console.warn('[SBH-bg] Could not load custom icons:', e.message);
  }
}

async function setIconSafe(active) {
  if (lastIcon === active) return;
  
  try {
    if (active && loadedIcons.on) {
      await chrome.action.setIcon({ imageData: loadedIcons.on });
    } else if (!active && loadedIcons.off) {
      await chrome.action.setIcon({ imageData: loadedIcons.off });
    } else {
      // Если картинки не загрузились, просто ничего не делаем (не спамим ошибками)
      return;
    }
    lastIcon = active;
    console.log('[SBH-bg] icon applied:', active ? 'on' : 'off');
  } catch (e) {
    console.error('[SBH-bg] setIcon error:', e.message);
  }
}

async function updateIcon() {
  try {
    const a = await chrome.storage.local.get(['sbh-cfg', 'sbh-stats']);
    const cfg = a['sbh-cfg'];
    const stats = a['sbh-stats'];
    const active = !!(cfg && cfg.enabled) || !!(stats && stats.saveRunning);
    await setIconSafe(active);
  } catch (e) {
    console.error('[SBH-bg] updateIcon error:', e);
  }
}

// Запуск
preloadIcons().then(() => updateIcon());

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes['sbh-cfg'] || changes['sbh-stats']) updateIcon();
});

chrome.runtime.onInstalled.addListener(() => updateIcon());
chrome.runtime.onStartup.addListener(() => updateIcon());

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && /selsup\.ru/.test(tab.url || '')) updateIcon();
  } catch {}
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'sbh-set-icon') {
    lastIcon = null;
    updateIcon();
    sendResponse({ ok: true });
    return;
  }
});